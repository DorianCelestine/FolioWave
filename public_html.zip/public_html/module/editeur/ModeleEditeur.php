<?php
	class ModeleEditeur{
		function __construct(){
		}
		public function connectUser(){
    	 
    	}
	}
?>