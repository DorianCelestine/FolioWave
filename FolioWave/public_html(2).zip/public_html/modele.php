<?php
	class Modele{
		function __construct(){
		}
		function sendMail(){
            $mail= htmlspecialchars($_POST['mail']);
            $sujet = htmlspecialchars($_POST['sujet']);
            $message =  htmlspecialchars($_POST['message']);
            $a = "foliowave.enterprise@gmail.com";
            $entete = "From:" . $mail;
            ini_set( 'display_errors', 1 );
            error_reporting( E_ALL );
            mail($a,$sujet,$message, $entete);
            unset($_POST['mail']);
            unset($_POST['sujet']);
            unset($_POST['message']);
            return true;
        }
	}
?>