<?php    
    class VueEditeur {
        
        public function getAff($contenu){
        	echo'<!DOCTYPE html>
                <html lang="fr">
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta http-equiv="X-UA-Compatible" content="ie=edge">
                        <title>FolioWave</title>
                        <script src="parallax.js"></script>
                        <link rel="stylesheet" href="index-style.css">
                        <link href="https://fonts.googleapis.com/css?family=Ubuntu:700&display=swap" rel="stylesheet">
                    </head>
                    
                    <body>'
                    .$contenu.
                    '</body>
                </html>';
        }

        public function getPalette(){
           	echo'
                        <div class="container">
                            <div class="header">
                                <div class="logo">
                                    <a href="index.php" id="title" class="wave"><img src="images/logo.png" alt="">FOLLIOWAVE</a>
                                </div>
                                <div class="navlist">
                                    <p><a href="#" class="wave" id="teste">CONTACT</a></p>
                                </div>
                            </div>
                            <div class="row center-screen">
                                <div class="col-2">
                                     <img src="./images/logo.png">
                                </div>
                                <div class="col-2">
                                     <img src="./images/logo.png">
                                </div>
                                <div class="col-2">
                                     <img src="./images/logo.png">
                                </div>
                                <div class="col-2">
                                     <img src="./images/logo.png">
                                </div>
                                <div class="col-2">
                                     <img src="./images/logo.png">
                                </div>
                            </div>
                        </div>
                    ';
        }

		public function getTemplate(){

		}

		public function getForm(){

		}
    }
?>
